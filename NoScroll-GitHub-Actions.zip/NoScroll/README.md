# NoScroll (Android MVP)

Experimental, on-device Accessibility Service that attempts to exit YouTube Shorts and Instagram Reels when it detects an **explicitly selected** Shorts/Reels tab in the accessibility tree.

## Build
Open the project folder in Android Studio (JDK 17, Android SDK 35), let Gradle sync, then Run on an Android device. This archive does not contain a Gradle wrapper or compiled APK. Alternatively install Gradle 8.9 and run `gradle assembleDebug` in the project root.

## Enable
Open NoScroll, turn on desired toggles, tap **Enable accessibility service**, and enable NoScroll in Android Accessibility settings.

## Known limitations
- Heuristic is intentionally conservative and **may not work** on current YouTube/Instagram versions or non-English interfaces.
- It only detects selected tab nodes labeled exactly Shorts or Reels; it does not block every route to short-form videos.
- It navigates back; it does not actually remove buttons from other apps.
- Accessibility events may contain sensitive screen information; this MVP does not persist or transmit them, and does not request Internet permission.
- Play Store distribution may require policy review and disclosure; intended for personal testing.

## Next steps
Collect **local, redacted** UI hierarchy diagnostics with explicit consent, develop version-specific detectors, test navigation paths, add debounce/cooldown tests and optional screen overlay. Never log message text or private screen content.

## Build an APK using GitHub Actions (no Android Studio needed)

1. Create a new **private** GitHub repository named `NoScroll`.
2. Upload the **contents** of this `NoScroll` folder to the repository root, including the hidden `.github/workflows/build-apk.yml` file. The easiest reliable method is GitHub Desktop or `git`.
3. Push to the `main` branch (or `master`). The **Build Android APK** workflow starts automatically. Alternatively go to **Actions → Build Android APK → Run workflow**.
4. Wait for the workflow to finish. Open the successful run, scroll to **Artifacts**, and download `NoScroll-debug-apk`.
5. Unzip the artifact and install `app-debug.apk` on your Android phone. You may need to allow installation from the browser or file manager.
6. Open NoScroll and enable its Accessibility Service manually in Android settings.

This produces a **debug-signed APK**, intended for personal testing, not a Play Store release. The workflow needs GitHub-hosted internet access to download build dependencies. The Shorts/Reels detection is experimental and may not work on your versions of YouTube and Instagram. NoScroll has no internet permission.
