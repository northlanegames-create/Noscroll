package com.example.noscroll

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 64, 48, 32) }
        root.addView(TextView(this).apply { text = "NoScroll — experimental blocker"; textSize = 23f })
        root.addView(TextView(this).apply { text = "Blocks detected short-video screens by navigating back. Detection may fail when apps update. All processing stays on-device."; textSize = 15f })
        listOf("youtube" to "Block YouTube Shorts", "instagram" to "Block Instagram Reels").forEach { (key, title) ->
            root.addView(Switch(this).apply {
                text = title; isChecked = prefs.getBoolean(key, true)
                setOnCheckedChangeListener { _, enabled -> prefs.edit().putBoolean(key, enabled).apply() }
            })
        }
        root.addView(Button(this).apply { text = "Enable accessibility service"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } })
        root.addView(TextView(this).apply { text = "In Accessibility settings, find NoScroll and enable it. You can disable it at any time. No network permission is requested." })
        setContentView(root)
    }
}
