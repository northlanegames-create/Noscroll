package com.example.noscroll

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.SystemClock

class ShortsBlockService : AccessibilityService() {
    private var lastBack = 0L
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        val key = when (pkg) {
            "com.google.android.youtube" -> "youtube"
            "com.instagram.android" -> "instagram"
            else -> return
        }
        if (!getSharedPreferences("settings", MODE_PRIVATE).getBoolean(key, true)) return
        if (SystemClock.elapsedRealtime() - lastBack < 1800) return
        val root = rootInActiveWindow ?: return
        // Conservative heuristic: require a selected tab with the exact short-video label.
        // App versions/locales may expose different UI trees, so this is intentionally experimental.
        val target = if (key == "youtube") "shorts" else "reels"
        val found = containsSelectedTab(root, target, 0)
        if (found) {
            lastBack = SystemClock.elapsedRealtime()
            performGlobalAction(GLOBAL_ACTION_BACK)
        }
    }
    private fun containsSelectedTab(node: AccessibilityNodeInfo, target: String, depth: Int): Boolean {
        if (depth > 18) return false
        val label = listOfNotNull(node.text?.toString(), node.contentDescription?.toString())
            .joinToString(" ").trim().lowercase()
        if (node.isSelected && (label == target || label == "$target tab")) return true
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            if (containsSelectedTab(child, target, depth + 1)) return true
        }
        return false
    }
    override fun onInterrupt() = Unit
}
